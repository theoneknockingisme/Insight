export default function NotFound() {
  return <div className="text-white/70">Not found.</div>
}
