export default function Loading() {
  return <div className="text-white/70">Loading Insight...</div>
}
